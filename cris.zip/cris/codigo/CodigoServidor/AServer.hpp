#ifndef _A_SERVER_HPP
#define _A_SERVER_HPP

#include "Commands.hpp"
#include "DataBase.hpp"
#include <cstdlib>
#include <iostream>
#include <boost/bind.hpp>
#include <boost/asio.hpp>

constexpr unsigned PORT = 17000;

extern DataBase base_dados;

class TCPConnection{
	private:
		boost::asio::ip::tcp::socket connected_socket;
		boost::asio::streambuf input_buffer;
		Command comando;
	public:
  	TCPConnection(boost::asio::io_service&);
		boost::asio::ip::tcp::socket& socket(void);
		void start(void);
		void handle_read(const boost::system::error_code&);
  	void handle_write(const boost::system::error_code&);
};

class TCPServer{
	private:
		boost::asio::io_service& io;
		boost::asio::ip::tcp::acceptor accep;
	public:
	  TCPServer(boost::asio::io_service&);
		void handle_accept(TCPConnection*, const boost::system::error_code&);
};

#endif
