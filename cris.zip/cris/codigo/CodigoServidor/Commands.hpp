#ifndef _COMMANDS_HPP
#define _COMMANDS_HPP
#include <iostream>
#include <boost/tokenizer.hpp>
#include <string>


#define DELIMITER " "

constexpr int DEFAULT_VALUE = -1; // Dummy Value inserido no
constexpr int MAX_JUMP_VALUE = 21; // Indíce máximo de acesso à jump table da base de dados
constexpr int HASH_TABLES = 3; // 3 é o máximo numero de argumentos num comando
constexpr int HASH_TABLE_LENGTH[] = {'z' - 'a' + 1, 'z' - '1' + 1, 'z' - '0' + 1};
extern std::vector <unsigned> hash_table[HASH_TABLES];
const std::vector <char> ARGUMENTS[HASH_TABLES] = { // Possíveis argumentos das tabelas
  {'g','s','r','b','c','d'},
  {'l', 'd', 'o', 'L', 'O', 'r', 'p', 'e', 'c', 'v', '1', '2'},
  {'0', '1', '2', 'T'},
  };
const std::vector <unsigned> VALUES[HASH_TABLES] = {  // Valores correspondentes aos argumentos
  {0, 14, 15, 16, 18, 20},
  {0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 0, 0},
  {0, 0, 0, 1},
  };

class Command{
  private: // Atributos
    bool command_invalid; // Se igual a true -> Comando é inválido
    unsigned jump_value;  // Atributo que determina qual a função correspondente ao comando a ser efetuado
    std::vector <char> args; // Vetor utilizado para armazenar os argumentos que a função getTokens retorna
  public: // Métodos
    Command(void);
    void getHashValue(std::string);
    bool CommandInvalid(void);
    unsigned getJumpValue(void);
    const std::vector <char>& getArgs(void);
};

#endif //_COMMANDS_HPP
