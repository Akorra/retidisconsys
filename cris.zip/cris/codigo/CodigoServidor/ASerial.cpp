#include "ASerial.hpp"
using namespace boost::system;
using namespace boost::asio;
//GLOBALS

std::mutex mtx_to_SP;
std::mutex mtx_to_OB;

extern std::string o_luminaires_buffer[LUMINAIRES];

void Luminaire::timer_handler(const error_code &ec)	{
  std::ostringstream os; os << o_luminaires_buffer[luminaire];
  o_luminaires_buffer[luminaire].clear();
  async_write(s_port,	buffer(os.str()),	boost::bind(&Luminaire::write_handler, this, placeholders::error, placeholders::bytes_transferred)); //timer expired – launch new write operation
}
void Luminaire::write_handler(const error_code &ec,	size_t nbytes){
  tim.expires_from_now(boost::posix_time::milliseconds(time_millisec));  //writer done – program new deadline
  tim.async_wait(boost::bind(&Luminaire::timer_handler, this, placeholders::error));
}
void Luminaire::read_handler(const error_code &ec,	size_t nbytes){
  std::string data; std::istream input_stream(&input_buffer); std::getline(input_stream, data);
  base_dados.setLuminaireInfo(data, luminaire);
  async_read_until(s_port, input_buffer,'\n', boost::bind(&Luminaire::read_handler, this, placeholders::error, placeholders::bytes_transferred)); //program new read cycle
}

Luminaire::Luminaire(unsigned lum, unsigned time_mili, io_service& io) : io(io), s_port(io), tim(io), time_millisec(time_mili){
  boost::system::error_code ec;
  std::string address = SP_ADDRESS + std::to_string(lum);
  s_port.open(address, ec); //connect to	port
  s_port.set_option(serial_port_base::baud_rate(BAUD_RATE), ec);
  tim.expires_from_now(boost::posix_time::milliseconds(time_millisec)); //program timer for	write operations
  tim.async_wait(boost::bind(&Luminaire::timer_handler, this, placeholders::error));
  async_read_until(s_port,input_buffer,'\n', boost::bind(&Luminaire::read_handler, this, placeholders::error, placeholders::bytes_transferred)); //program chain of read operations
}
