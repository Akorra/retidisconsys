#include "DataBase.hpp"
#include "AServer.hpp"
#include "ASerial.hpp"
#include <thread>
#include <iostream>

boost::asio::io_service io1, io2;

constexpr unsigned TIME = 100;
DataBase base_dados;
std::string o_luminaires_buffer[LUMINAIRES]; // Output buffers das luminárias

void run_service1(){io1.run();}
void run_service2(){io2.run();}

Luminaire luminaire1{0, TIME, io1}; // Classe que implementa a comunicação com uma luminária.
// 1 parametro -> nº do porto série, 2 parametro -> frequência do handle_write, 3 parametro -> objeto io

int main(){

  TCPServer server(io2);
  std::thread t1{run_service1};
  std::thread t2{run_service2};
  t1.join();
  t2.join();
}
