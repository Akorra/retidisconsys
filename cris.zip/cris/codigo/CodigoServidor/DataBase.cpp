#include "DataBase.hpp"
#include <iostream>

using namespace std;
using namespace boost;
mutex mtx_to_set_occup_state;
mutex mtx_to_reset;
mutex to_LumOBuff;

extern std::string o_luminaires_buffer[LUMINAIRES];

DataBase::DataBase(){	// Ctor --> Initialize all attributes to zero
	for(int i = 0; i != LUMINAIRES; i++){
		lux[i].set_capacity(CB_SIZE);
		duty_cycle[i].set_capacity(CB_SIZE);
	}
	InitiateDataBase();
}

void DataBase::InitiateDataBase(void){ // Function to start or restart system
	for(unsigned int i = 0; i != LUMINAIRES ;i++){ // Clear circular buffers in restart
		lux[i].clear(); duty_cycle[i].clear();
	}
	fill(occupancy_state, occupancy_state + LUMINAIRES, 0);
	fill(lower_bound, lower_bound + LUMINAIRES, 0);
	fill(external_lux, external_lux + LUMINAIRES, 0);
	fill(control_ref, control_ref + LUMINAIRES, 0);
	fill(power_consumption, power_consumption + LUMINAIRES, 0);
	fill(accumulated_energy, accumulated_energy + LUMINAIRES, 0);
	fill(confort_error, confort_error + LUMINAIRES, 0);
	fill(confort_variance, confort_variance + LUMINAIRES, 0);
	fill(n, n + LUMINAIRES, 0);
}

string DataBase::getRequestedInfo(unsigned command, const vector<char>& args){	// Get the requested info
	unsigned lum;			// São passados os argumentos do comando para verificar se nao existiram colisões
	switch(command){
		case 0:	// GetCurrentLux func no. 0
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'l' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				if(lux[lum - 1].empty())
					return "Não inicializado\n";
				return "l " + to_string(lum) + " " + to_string(lux[lum - 1].back()) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 1: // GetCurrentDutyCycle func no. 1
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'd' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				if(duty_cycle[lum - 1].empty())
					return "Não inicializado\n";
				return "d " + to_string(lum) + " " + to_string(duty_cycle[lum - 1].back()) + "\n";
			}
		else
			return ERROR_MESSAGE;
		case 2: // GetCurrentOccupancyState func no. 2
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'o' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				return "o " + to_string(lum) + " " + to_string(occupancy_state[lum - 1]) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 3: // GetCurrentLowerBound func no. 3
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'L' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				return "L " + to_string(lum) + " " + to_string(lower_bound[lum - 1]) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 4: // getCurrentExternalLux func no. 4
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'O' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				return "O " + to_string(lum) + " " + to_string(external_lux[lum - 1]) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 5: // getCurrentControlRef func no. 5
			if(args.size() != 3)
				return ERROR_MESSAGE;;
			if(args[0] == 'g' && args[1] == 'r' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				return "r " + to_string(lum) + " " + to_string(control_ref[lum - 1]) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 6: // getInstantPower func no. 6
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'p' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				return "p " + to_string(lum) + " " + to_string(power_consumption[lum - 1]) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 7: // getInstantTotalPower func no. 7
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'p' && args[2] == 'T'){
				double total_power = 0;
				for(int i = 0; i != LUMINAIRES; i++)
					total_power += power_consumption[i];
				return "p T " + to_string(total_power) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 8: // getAccumulatedEnergy func no. 8
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'e' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				return "e " + to_string(lum) + " " + to_string(accumulated_energy[lum - 1]) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 9: // getTotalAccumulatedEnergy func no. 9
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'e' && args[2] == 'T'){
				double total_energy = 0;
				for(int i = 0; i != LUMINAIRES; i++)
					total_energy += accumulated_energy[i];
				return  "e T " + to_string(total_energy) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 10: // getAccumulatedConfortError func no. 10
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'c' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				return "c " + to_string(lum) + " " + to_string(confort_error[lum - 1]/n[lum - 1]) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 11: // getTotalAccumulatedConfortError func no. 11
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'c' && args[2] == 'T'){
				double total_confort_error = 0;
				for(int i = 0; i != LUMINAIRES; i++)
					total_confort_error += confort_error[i];
				return "c T " + to_string(total_confort_error) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 12: // getAccumulatedConfortVariance func no. 12
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'g' && args[1] == 'v' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				return "v " + to_string(lum) + " " + to_string(confort_variance[lum - 1]/(n[lum - 1])) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 13: // getTotalAccumulatedConfortVariance func no. 13
			if(args.size() != 3)
				return "erro";
			if(args[0] == 'g' && args[1] == 'v' && args[2] == 'T'){
				double total_confort_var = 0;
				for(int i = 0; i != LUMINAIRES; i++)
					total_confort_var += confort_variance[i];
				return "v T " + to_string(total_confort_var) + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 14: // setOccupancyState func no. 14
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 's' && args[1] - '0' > 0 && args[1] - '0' <= LUMINAIRES && (args[2] == '0' || args[2] == '1')){
				lum = args[1] - '0';
				mtx_to_set_occup_state.lock();
				if(occupancy_state[lum - 1] != args[2]){
					WriteToOutputLumBuffer('s', lum - 1);
					occupancy_state[lum - 1] = !occupancy_state[lum - 1];
				}
				mtx_to_set_occup_state.unlock();
				return "ack\n";
			}
			else
				return ERROR_MESSAGE;
		case 15: // restartSystem func no. 15
			if(args.size() != 1)
				return ERROR_MESSAGE;
			if(args[0] == 'r'){
				mtx_to_reset.lock();
				for(int i = 0; i != LUMINAIRES; i++)
						WriteToOutputLumBuffer('r', lum - 1);
				InitiateDataBase();
				mtx_to_reset.unlock();
				return "ack\n";
			}
			else
				return ERROR_MESSAGE;
		case 16: // getLastMinBuffLux func no. 16
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'b' && args[1] == 'l' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				string s = "";
				for(unsigned i = 0; i != lux[lum - 1].size(); i++)
					s += to_string(lux[lum - 1][i]) + ", ";
				return "b l " + to_string(lum) + " " + s + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 17: // getLastMinBuffDutyCycle func no. 17
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'b' && args[1] == 'd' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				string s = "";
				for(unsigned i = 0; i != duty_cycle[lum - 1].size(); i++)
					s += to_string(duty_cycle[lum - 1][i]) + ", ";
				return "b d " + to_string(lum) + " " + s + "\n";
			}
			else
				return ERROR_MESSAGE;
		case 18: // startStreamLux func no. 18
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'c' && args[1] == 'l' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				//stream_lux_on[lum - 1] = true;
			return "c I " + to_string(lum + 1) + " " + to_string(lux[lum].back()) + "\n";
			}
		case 19: break;// startStreamDutyCycle func no. 19
			if(args.size() != 3)
				return ERROR_MESSAGE;
			if(args[0] == 'c' && args[1] == 'l' && args[2] - '0' > 0 && args[2] - '0' <= LUMINAIRES){
				lum = args[2] - '0';
				//stream_dc_on[lum - 1] = true;
			return "c I " + to_string(lum + 1) + " " + to_string(lux[lum].back()) + "\n";
			}
		case 20: break;// stopStreamLux func no. 20
		case 21: break;// stopStreamDutyCycle func no. 21
	}
}

void DataBase::WriteToOutputLumBuffer(char s, unsigned lum){
	to_LumOBuff.lock();
	o_luminaires_buffer[lum].push_back(s);
	to_LumOBuff.unlock();
}


inline bool DataBase::IsDouble(const string& token){
	for(int i = 0; i != token.length(); i++)
		if(!isdigit(token[i]))
			if(token[i] == '.') // '.' pertence a um número do tipo floating point
				;
			else // Else -> Existe erro no envio da string
				return false;
	return true;
}

void DataBase::setLuminaireInfo(string data, unsigned lum){ // Função utilizada pelos Luminaires para passarem a informação para a Base de dados
	char_separator <char> separator(" ");
	tokenizer <char_separator <char>> tokens(data, separator);
	tokenizer <char_separator <char>>::iterator current_token;
	vector <string> current_tokens;
	for(current_token = tokens.begin(); current_token != tokens.end(); ++current_token)
		current_tokens.push_back(*current_token);
	if(current_tokens.size() != 6) // lux duty_cycle occupancy_state lower_bound external_lux control_ref
		return;
	int j = 0;
	//*******************GET DATA FROM LUMINAIRE**********************************
	if(!IsDouble(current_tokens[j]))
		return;
	lux[lum].push_back(stod(current_tokens[j++]));
	if(!IsDouble(current_tokens[j]))
		return;
	duty_cycle[lum].push_back(100/255.0 * stoi(current_tokens[j++]));
	if(!IsDouble(current_tokens[j]))
		return;
	occupancy_state[lum] = stoi(current_tokens[j++]);
	if(!IsDouble(current_tokens[j]))
		return;
	lower_bound[lum] = stod(current_tokens[j++]);
	if(!IsDouble(current_tokens[j]))
		return;
	external_lux[lum] = stod(current_tokens[j++]);
	if(!IsDouble(current_tokens[j]))
		return;
	control_ref[lum] = stod(current_tokens[j++]);
	//***************************END**********************************************
	double aux_calc;
	aux_calc = duty_cycle[lum].back()/100; power_consumption[lum] = aux_calc;
	accumulated_energy[lum] += aux_calc * PERIOD;
	aux_calc = control_ref[lum] - lux[lum].back(); confort_error[lum] += aux_calc > 0 ? aux_calc : 0;
	if(lux[lum].size() > 2)
		confort_variance[lum] = abs(lux[lum][lux[lum].size() - 1] - 2*lux[lum][lux[lum].size() - 2] + lux[lum][lux[lum].size() - 3])/SQUARED_PERIOD;
	n[lum]++;
}
