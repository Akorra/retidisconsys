#include "Commands.hpp"

using namespace boost; using namespace std;
vector <unsigned> hash_table[HASH_TABLES]; // criação de 3 hash_tables

Command::Command(void){
  int i, size;
  for(i = 0; i != HASH_TABLES; ++i)
    for(int j = 0; j != HASH_TABLE_LENGTH[i]; ++j)
      hash_table[i].push_back(DEFAULT_VALUE);  // Inicializar tudo a -1
  for(i = 0, size = ARGUMENTS[0].size(); i != size; ++i)
    hash_table[0][ARGUMENTS[0][i] - 'a'] = VALUES[0][i]; // Inicializar 1ª Hash table
  for(i = 0, size = ARGUMENTS[1].size(); i != size; ++i)
    hash_table[1][ARGUMENTS[1][i] - '1'] = VALUES[1][i]; // Inicializar 2ª Hash table
  for(i = 0, size = ARGUMENTS[2].size(); i != size; ++i)
    hash_table[2][ARGUMENTS[2][i] - '0'] = VALUES[2][i]; // Inicializar 3ª Hash table
}

void Command::getHashValue(string msg){
  jump_value = command_invalid = 0; args.clear(); // Limpar os atributos
  char_separator <char> separator(DELIMITER);
  tokenizer <char_separator <char>> tokens(msg, separator);
  tokenizer <char_separator <char>>::iterator curr_tok, end;
  int i, size;
  for(i = 1, curr_tok = tokens.begin(), end = tokens.end(); curr_tok != end; ++curr_tok, ++i)
    if(curr_tok->size() != 1){ // Se argumento não é char -> set à Flag de Invalido
      command_invalid = true; return;
    }
    else if(i > HASH_TABLES){ // Se argumento é maior que o máximo -> set à Flag de Invalido
      command_invalid = true; return;
    }
    else
      args.push_back(((string)*curr_tok)[0]); // Insere argumento no vetor

  unsigned index;
  i = 0; size = args.size();
//***************Para o primeiro argumento*********************
  if(i == size){
    command_invalid = true; return; // Comando invalido se não existir argumentos no vetor
  }
  index = args[i] - 'a';            // Hash Function nº1
  if(index >= HASH_TABLE_LENGTH[i]){ // Caso o indice da tabela seja maior que o devido retorna comando inválido
  command_invalid = true; return;
  }
  if(hash_table[i][index] == DEFAULT_VALUE){ // Caso obtenha um dummy value(-1) retorna comando inválido
  command_invalid = true; return;
  }
  jump_value += hash_table[i++][index]; // Soma o valor da hash table
//*********************END**************************************
//***************Para o segundo argumento***********************
  if(i == size){
    return;
  }
  index = args[i] - '1';          // Hash Function nº2
  if(index >= HASH_TABLE_LENGTH[i]){
    command_invalid = true; return;
  }
  if(hash_table[i][index] == DEFAULT_VALUE){
    command_invalid = true; return;
  }
  jump_value += hash_table[i++][index];
//************************END************************************
//***************Para o terceiro argumento***********************
  if(i == size){
    return;
  }
  index = args[i] - '0';          // Hash Function nº3
  if(index >= HASH_TABLE_LENGTH[i]){
    command_invalid = true; return;
  }
  if(hash_table[i][index] == DEFAULT_VALUE){
    command_invalid = true; return;
  }
  jump_value += hash_table[i++][index];
//************************END************************************
  if(jump_value > MAX_JUMP_VALUE)
    command_invalid = true;
}

bool Command::CommandInvalid(void){
  return command_invalid;
}
unsigned Command::getJumpValue(void){
  return jump_value;
}

const std::vector<char>& Command::getArgs(void){
  return args; // Funcão utilizada pela classe DataBase para para obter os argumentos do comando
}
