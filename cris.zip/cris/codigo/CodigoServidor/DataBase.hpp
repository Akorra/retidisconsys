#ifndef _DATA_BASE_H
#define _DATA_BASE_H

#include <string> // For stod
#include <boost/circular_buffer.hpp> // For circular_buffer
#include <cmath>	// Used to compute absolute value
#include <boost/tokenizer.hpp>
#include <mutex>

#define ERROR_MESSAGE "Comando Inválido \n"
extern std::mutex mtx_to_set_occup_state;
extern std::mutex mtx_to_reset;
extern std::mutex to_LumOBuff;

constexpr unsigned LUMINAIRES = 1;
constexpr unsigned TO_COMPUTE_DERIVATIVE_N = 3; // Para calcular a derivada de 2 ordem;
constexpr double PERIOD = 0.1;
constexpr double SQUARED_PERIOD = PERIOD * PERIOD;
constexpr unsigned int CB_SIZE = 60/PERIOD; 	// Buffer Circular SIZE -> 60/(Periodo [s])

class DataBase{
	private:
		// DataBase Inner Attributes
		boost::circular_buffer <double> lux[LUMINAIRES];
		boost::circular_buffer <double> duty_cycle[LUMINAIRES];
	 	bool occupancy_state[LUMINAIRES];
	 	double lower_bound[LUMINAIRES];
	 	double external_lux[LUMINAIRES];
	 	double control_ref[LUMINAIRES];
	 	double power_consumption[LUMINAIRES];
	 	double accumulated_energy[LUMINAIRES];
	 	double confort_error[LUMINAIRES]; // Not Normalized! Need to be normalized in the used function
	 	double confort_variance[LUMINAIRES]; // Not Normalized! Need to be normalized in the used function
		unsigned n[LUMINAIRES]; // Variable used to compute Confort and Variance Error

	public: // Methods
		DataBase(void);	// Ctor --> Initialize all attributes to zero
		std::string getRequestedInfo(unsigned, const std::vector<char>&); // Function used to get requested info from a command
		void setLuminaireInfo(std::string, unsigned); // Function used by Luminaires to insert data in DataBase
	private:
		void InitiateDataBase(void);	// Function to start or restart system
		void WriteToOutputLumBuffer(char, unsigned);
		inline bool IsDouble(const std::string&); // Function used to check if  the token is a number
};

#endif //_DATA_BASE_H
