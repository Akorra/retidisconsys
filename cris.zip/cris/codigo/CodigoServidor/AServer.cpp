#include "AServer.hpp"

using namespace boost::asio;
using namespace boost::system;
using boost::asio::ip::tcp;

//***********************TCPCONNECTION METHODS**********************************

TCPConnection::TCPConnection(io_service& io) : connected_socket(io){}

tcp::socket& TCPConnection::socket(void){
  return connected_socket;
}
void TCPConnection::start(void){
  async_read_until(connected_socket, input_buffer, '\n', boost::bind(&TCPConnection::handle_read, this, _1));
}

void TCPConnection::handle_read(const error_code& error){
  if(!error){
    std::string line; std::istream is(&input_buffer); std::getline(is, line);
    if(line.empty())
      TCPConnection::start();
    else{
      std::string response;
      comando.getHashValue(line);
      if(comando.CommandInvalid())
        response = "Commando inválido\n";
      else{
        response = base_dados.getRequestedInfo(comando.getJumpValue(), comando.getArgs());
      }
      async_write(connected_socket, buffer(response), boost::bind(&TCPConnection::handle_write, this, placeholders::error));
    }
  }
  else
    delete this;
}
void TCPConnection::handle_write(const error_code& error){
	if(!error)
  	async_read_until(connected_socket, input_buffer, '\n', boost::bind(&TCPConnection::handle_read, this, _1));
  else
  	delete this;
}

//************************TCPSERVER METHODS*************************************

TCPServer::TCPServer(io_service& iox) : io(iox), accep(iox, tcp::endpoint(tcp::v4(), PORT)){
  TCPConnection* new_TCPConnection = new TCPConnection(io);
	accep.async_accept(new_TCPConnection->socket(), boost::bind(&TCPServer::handle_accept, this, new_TCPConnection, placeholders::error));
}
void TCPServer::handle_accept(TCPConnection* new_TCPConnection, const error_code& error){
	if(!error){
	  new_TCPConnection->start();
	  new_TCPConnection = new TCPConnection(io);
	  accep.async_accept(new_TCPConnection->socket(), boost::bind(&TCPServer::handle_accept, this, new_TCPConnection, placeholders::error));
	  }
	else
	 delete new_TCPConnection;
}
