#ifndef A_SERIAL_HPP
#define A_SERIAL_HPP

#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <mutex>
#include <iostream>
#include "DataBase.hpp"

extern DataBase base_dados;

constexpr unsigned BAUD_RATE = 115200;

#define SP_ADDRESS "/dev/ttyACM"
extern std::mutex mtx_to_SP;
extern std::mutex mtx_to_OB;

class Luminaire{
  private:
    unsigned luminaire;
    //static unsigned luminaires; // class attribute
    boost::asio::io_service& io;
    boost::asio::serial_port s_port;
    boost::asio::deadline_timer tim;
    boost::system::error_code ec;
    boost::asio::streambuf input_buffer;
    std::string output_string;
    unsigned time_millisec;
  public:
    Luminaire(unsigned, unsigned, boost::asio::io_service&);
    unsigned getLuminaire(void);
    void sendDataToLuminaire(char);
  private:
    void write_handler(const boost::system::error_code&, size_t);
    void timer_handler(const boost::system::error_code&);
    void read_handler(const boost::system::error_code&, size_t);

};

#endif //A_SERIAL_HPP
