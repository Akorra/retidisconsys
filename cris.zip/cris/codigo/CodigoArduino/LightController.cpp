#include "LightController.h"

LightController light1 = LightController();

/* DEFAULT CONSTRUCTOR */
LightController::LightController()
{
	y_ant = 0;
	i_ant = 0;
	e_ant = 0;
	y=0;
	e = 0;
	p = 0;
	i = 0;
	e_sat = 0;
	K1 = KP;
	K2 = KP*KI/2;
	pwm = 0;

//--------------------------CONSENSUS---------------------------------//

   //d_pwm_av = (int*) calloc(2,sizeof(int)); //inicialize to zero
   d_pwm_aux = (float*) calloc(2,sizeof(float)); //inicialize to zero
   d_pwm_best = (int*) calloc(2,sizeof(int)); //inicialize to zero
   lambdas = (float*) calloc(2,sizeof(float)); //inicialize to zero
   z = (float*) calloc(2,sizeof(float)); //inicialize to zero
   v = (float*) calloc(2,sizeof(float)); //inicialize to zero
   g=0;             
   cost=COST;         
   e_cost=E_COST;  
   norm_gain=0;     
   norm_gain_2=0;  
   min_best=1000;
  
}

LightController::~LightController()
{
  free (d_pwm_aux);
  free (d_pwm_best);
  free (lambdas);
  free (z);
  free (v);
}

void LightController::Memory_Realloc()
{
  if(sizeof(d_pwm_av)!= Get_Number_Nodes())
  {
    //realloc(d_pwm_av, n_nodes*sizeof(int));
    realloc(d_pwm_aux, n_nodes*sizeof(float));
    realloc(d_pwm_best, n_nodes*sizeof(int));
    realloc(lambdas,n_nodes*sizeof(float));
    realloc(z,n_nodes*sizeof(float));
    realloc(v,n_nodes*sizeof(float));
  }
  else 
    return;
}

void LightController::LightControllerSetup()
{
}

void LightController::FeedForward()
{
  if(flag_consensus == false)
  {
    pwm = Convert_Lux_PWM();
  }

  else if(flag_consensus == true)
  {
    light1.Memory_Realloc();
    ConsensusAlgorithm();
    float value_lux = Convert_ADC_Lux(Aquire_Samples(40));
    lux_ref = value_lux;
  }
  
  dc_pwm[address_position] = pwm;
  analogWrite(DIGITAL_PIN,pwm);
}

void LightController::PIController()
{
  float value_lux = Aquire_Samples(100);
  y = Convert_ADC_Lux(value_lux);
    
	e = Get_Lux_Ref() - y;
      
  if(e >  -0.05 && e <  0.05)
    e=0; 

    p = K1*e;
    i = i_ant + K2*(e+e_ant);
    pwm = pwm + p + i;
        
    if(pwm >= 255)
      {
        e_sat = 255 - pwm;
        pwm = 255;
      }
    else if (pwm < 0)
      {
        e_sat = - pwm;
        pwm = 0;
      }
    else
      e_sat = 0;

    analogWrite(DIGITAL_PIN,pwm);
    dc_pwm[address_position] = pwm;
    i_ant = i+e_sat/50.;
    y_ant = y;
    e_ant = e; 

}

float LightController::Calculate_External_Light()
{
  float aux=y;
  for(n_master = 0; n_master<n_nodes; ++n_master)
  {
    aux -= gain[0][n_master]*dc_pwm[n_master];
  }
  if(aux <0)
  aux = 0;
  return aux;
}

//--------------------------CONSENSUS---------------------------------//
float LightController::CostFunction()
{
  float sum=0.;
  float resul=0.;
  
  for(int i=0;i<n_nodes;i++)
  {
    sum += (RHO*0.5*(d_pwm_aux[i] - d_pwm_av[i]) + lambdas[i])* (d_pwm_aux[i] - d_pwm_av[i]);
  }

  resul = sum + 0.5*e_cost*d_pwm_aux[address_position] * d_pwm_aux[address_position] + cost*d_pwm_aux[address_position];
  return resul;
}

void LightController::Unconstrained_Sol()
{
  for(int i=0;i<n_nodes;i++)
  {
   if(i==address_position)
    d_pwm_aux[i]= z[i]/(RHO+e_cost);   
   else
    d_pwm_aux[i]=z[i]/RHO;
  }
}


void LightController::AuxilarCalc()
{
  norm_gain = 0;
  norm_gain_2=0;
  for(int i=0;i<n_nodes;i++)
  {
  lambdas[i] = lambdas[i] + RHO*(d_pwm_best[i] - d_pwm_av[i]);
    if(i==address_position)
    {
      z[i]= -cost-lambdas[i]+RHO*d_pwm_av[i];
      v[i]=0;
      norm_gain +=gain[0][i]*gain[0][i]/(RHO+e_cost);
      norm_gain_2+=0;    
    }
    else
    {
      z[i]= -lambdas[i]+RHO*d_pwm_av[i];
      v[i]=z[i]*gain[0][i];
      norm_gain+=gain[0][i]*gain[0][i]/RHO;
      norm_gain_2+=gain[0][i]*gain[0][i];
    }
  }
  g=(RHO+e_cost)/(norm_gain*(RHO+e_cost)-gain[0][address_position]*gain[0][address_position]);
}

void LightController::Linear_Sol()
{
  float sum = 0;// -il_0[address_position][address_position] + lux_ref;

  for(int i=0;i<n_nodes;i++)
  {
    if(i==address_position)
     sum -= gain[0][i]*z[i]/(RHO+e_cost);
    else
      sum -= gain[0][i]*z[i]/(RHO);
  }
  sum -= il_0[0][address_position] - lux_ref;
  for(int i=0;i<n_nodes;i++)
  {
    if(i==address_position)
     d_pwm_aux[i]=z[i]/(RHO+e_cost) + (gain[0][i]/(norm_gain*(RHO+e_cost)))*sum;
    else
     d_pwm_aux[i]=z[i]/RHO + (gain[0][i]/(norm_gain*RHO))*sum;
   }
}


void LightController::LowerBoundary_Sol()
{
  for(int i=0;i<n_nodes;i++)
  {
    if(i==address_position)
     d_pwm_aux[i]=0;
    else
     d_pwm_aux[i]=z[i]/RHO;
   }
}

void LightController::UpperBoundary_Sol()
{
  for(int i=0;i<n_nodes;i++)
  {
    if(i==address_position)
     d_pwm_aux[i]=255;
    else
     d_pwm_aux[i]=z[i]/RHO;
  }
}

void LightController::Linear_Lower_Sol()
{
  for(int i=0;i<n_nodes;i++)
  {
    if(i==address_position)
      d_pwm_aux[i]=z[i]/(RHO+e_cost) + (g*norm_gain_2*z[i])/(RHO*(RHO+e_cost));
    else
     d_pwm_aux[i]=z[i]/RHO + (g/RHO)*gain[0][i]*(lux_ref-il_0[0][address_position])-gain[0][i]*v[i]/RHO;
  } 
}

void LightController::Linear_Upper_Sol()
{
  for(int i=0;i<n_nodes;i++)
  {
    if(i==address_position)
      d_pwm_aux[i]=z[i]/(RHO+e_cost) + (g/RHO)*(255*norm_gain_2-(norm_gain_2*z[i])/(RHO+e_cost));
    else
     d_pwm_aux[i]=z[i]/RHO + (g/RHO)*(gain[0][i]*(lux_ref-il_0[0][address_position])-255*gain[0][i]*gain[0][address_position]
     - (gain[0][i]*v[i])/RHO);
  } 
}

int LightController::Unconstrained_Region()
{
  float sum=0;
  for(int i=0; i<n_nodes; i++)
  {
    sum+=gain[0][i]*d_pwm_aux[i];
  }
  if(d_pwm_aux[address_position]<0 || d_pwm_aux[address_position]>255 || sum < lux_ref - il_0[address_position][address_position])
    return 0;
  else
    return 1;
}

int LightController::Linear_Region()
{
  if(d_pwm_aux[address_position]<0 || d_pwm_aux[address_position]>255)
    return 0;
  else
    return 1;
}

int LightController::LowerBoundary_Region()
{
  float sum=0;
  for(int i=0; i<n_nodes; i++)
  {
    sum+=gain[0][i]*d_pwm_aux[i];
  }
  if(d_pwm_aux[address_position]<0 || d_pwm_aux[address_position]>255 || sum < lux_ref - il_0[0][address_position])
    return 0;
  else
    return 1;
}

int LightController::UpperBoundary_Region()
{
  float sum=0;
  for(int i=0; i<n_nodes; i++)
  {
    sum+=gain[0][i]*d_pwm_aux[i];
  }
  if(d_pwm_aux[address_position]<0 || d_pwm_aux[address_position]>255 || sum < lux_ref - il_0[0][address_position])
    return 0;
  else
    return 1;
}

int LightController::Linear_Lower_Region()
{
   if(d_pwm_aux[address_position]>255)
    return 0;
  else
    return 1;
}

int LightController::Linear_Upper_Region()
{
   if(d_pwm_aux[address_position]<0)
    return 0;
  else
    return 1;
}


void LightController::Consensus_Minimun()
{
  float minimum = 0;
  min_best = 1000;

  Unconstrained_Sol();
  if (Unconstrained_Region() == 1)
  {
    minimum = CostFunction();
//    Serial.print("UR: "); Serial.println("minimum: ");
    if (minimum < min_best)
    {
      min_best = minimum;
      for (int i = 0; i < n_nodes; i++)
        d_pwm_best[i] = d_pwm_aux[i];
        return;
    }
  }
  Linear_Sol();
  if (Linear_Region() == 1)
  {
    minimum = CostFunction();
//    Serial.print("LR: "); Serial.println("minimum: ");
    if (minimum<min_best)
    {
      min_best = minimum;
      for (int i = 0; i<n_nodes; i++)
        d_pwm_best[i] = d_pwm_aux[i];
    }
  }
  LowerBoundary_Sol();
  if (LowerBoundary_Region() == 1)
  {
    minimum = CostFunction();
//    Serial.print("LBR: "); Serial.println("minimum: ");
    if (minimum<min_best)
    {
      min_best = minimum;
      for (int i = 0; i<n_nodes; i++)
        d_pwm_best[i] = d_pwm_aux[i];
    }
  }
  UpperBoundary_Sol();
  if (UpperBoundary_Region() == 1)
  {
    minimum = CostFunction();
//    Serial.print("UPR: "); Serial.println("minimum: ");
    if (minimum<min_best)
    {
      min_best = minimum;
      for (int i = 0; i<n_nodes; i++)
        d_pwm_best[i] = d_pwm_aux[i];
    }
  }
  Linear_Lower_Sol();
  if (Linear_Lower_Region() == 1)
  {
    minimum = CostFunction();
//    Serial.print("LLR: "); Serial.println("minimum: ");
    if (minimum<min_best)
    {
      min_best = minimum;
      for (int i = 0; i<n_nodes; i++)
        d_pwm_best[i] = d_pwm_aux[i];
    }
  }
  Linear_Upper_Sol();
  if (Linear_Upper_Region() == 1)
  {
    minimum = CostFunction();
//    Serial.print("LUR: "); Serial.println("minimum: ");
    if (minimum<min_best)
    {
      min_best = minimum;
      for (int i = 0; i<n_nodes; i++)
        d_pwm_best[i] = d_pwm_aux[i];
    }
  }
}

void LightController::ConsensusAlgorithm()
{
  n_master=0;
  
  for (int i = 0; i < N_ITER; i++)
 {
    AuxilarCalc();  
    Consensus_Minimun();
    pwm = d_pwm_best[address_position];
    analogWrite(DIGITAL_PIN,d_pwm_best[address_position]);
    for(n_master=0;n_master<n_nodes; n_master ++)
    {
      if(n_master==address_position)
      { 
        for(int i=0; i<n_nodes; i++)
        {
          if(i!=address_position)
          {
            Send_Event(CONSENSUS_PWM, d_pwm_best[i], address_list[i]);
          }
          else
            continue;          
        }
      }

      else
      { 
          WaitEvent(CONSENSUS_PWM,1);
          flag_consensus_pwm = 0;       
      }        
   }

  n_master=0;
  d_pwm_av[address_position] = 0;
   for(int i=0; i<n_nodes;i++)
   { 

      if(i==address_position)
        d_pwm_av[address_position]+=d_pwm_best[i];
      else
        d_pwm_av[address_position]+=d_arm_pwm[i];    
   }

   d_pwm_av[address_position]=d_pwm_av[address_position]/n_nodes;

    for(n_master=0;n_master<n_nodes; n_master ++)
    {
      if(n_master==address_position)
      { 
        Send_Event(CONSENSUS_AV, d_pwm_av[address_position]);
      }

      else
      { 
          WaitEvent(CONSENSUS_AV,1);
          flag_consensus_av = 0;       
      }        
    }
  }

   
}
