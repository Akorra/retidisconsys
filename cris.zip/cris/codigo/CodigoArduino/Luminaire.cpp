#include "Luminaire.h"

/* DEFAULT CONSTRUCTOR */
Luminaire::Luminaire()
{
  //shutdown LED
  analogWrite(DIGITAL_PIN,0);                       

  
  address = ADDRESS;                 //assign the address
  Wire.begin(address);               // join i2c bus 
  TWAR = (address << 1) | 1;         // enable broadcasts to be received

  //clear address_list buffer
  for(int i=0;i<127;i++)
  {
    address_list[i]=0;
  }

  //clar message decoder buffer
  msg_int[0]=0;
  msg_int[1]=0; 
  
  //clear circular buffer
  for(int i=0;i<50;i++)
  {
    msg_byte[i]=0;                                        
  }

  //assign lux ref values , starts off by default                                      
  lux_on = LUX_REF_ON;
  lux_off = LUX_REF_OFF;
  lux_ref = LUX_REF_OFF;

  //calibration mode 1 by default (whole matrix)
  calib_mode = 1; 

  //allocation of memory for necessary matrixes and vectores
  occupation_state = (int*) calloc(2,sizeof(int)); //inicialize with no occupation
  gain = (float**) malloc(2*sizeof(float*));
  inv_gain = (float**) malloc(2*sizeof(float*));
  il_0 = (float**) malloc(2*sizeof(float*));
  dc_pwm = (int*) calloc(2,sizeof(int));

  for(int i = 0; i<2; ++i)
  {
    gain[i] = (float*) calloc(2,sizeof(float));
    inv_gain[i] = (float*) malloc(2*sizeof(float));
    il_0[i] = (float*) calloc(2,sizeof(float));
  }
  
  d_arm_pwm=(int*) calloc(2,sizeof(int)); //inicialize to zero
  d_pwm_av = (int*) calloc(2,sizeof(int)); //inicialize to zero

}

/* DESCONSTRUCTOR*/
Luminaire::~Luminaire()
{
  for (int i = 0; i < n_nodes; i++)
  {
    free (gain[i]);
    free (inv_gain[i]);
    free (il_0[i]);
  }

  free (gain);
  free (inv_gain);
  free (il_0);
  free (occupation_state);
  free (dc_pwm);  
  free (d_arm_pwm);
  free (d_pwm_av);
}

/********************************************* NETWORK INFORMATION *********************************************************/

//get number of nodes in network
void Luminaire::Find_Number_Nodes()
{
  byte count = 0;

  //iterate on all possible addresses
  for (byte i = 9; i < 127; i++)
  {
    //if equal to this node address
    if(i == address)
    {
      address_list[count] = address;
      address_position = count;
      count ++;
    }
    
    //if not tries to estabilish communication
    else
    {
      //send message
      Wire.beginTransmission (i);
      Wire.write(1023);
      Wire.write(1023);

      //if response received
      if(Wire.endTransmission () == 0)
      {
         //store address
         address_list[count] = i;
         count ++; 
      } 
    } 
  }

  //store number of nodes
  n_nodes = (int)count;

  //send message informing network of the number of nodes found
  Send_Event(N_NODES,(int)n_nodes);
}

//auxiliary prints all network addresses
void Luminaire::Print_Addresses()
{
  for(int i=0; i<n_nodes;++i)
  {
    Serial.print ("Found address: ");
    Serial.print (address_list[i], DEC);
    Serial.print (" (0x");
    Serial.print (address_list[i], HEX);
    Serial.println (")");
  }

  Serial.println ("Done.");
  Serial.print ("Found ");
  Serial.print (n_nodes, DEC);
  Serial.println (" device(s).");
}

/***************************************************** SET FUNCTIONS ********************************************************/

//make lux_on and lux_off a value possible for the ADC
void Luminaire::Set_Lux_ref(void)
{
  int VADC = 0;

  //convert lux to adc channel, round
  VADC = Convert_Lux_ADC(lux_on);
  //reconvert back to lux
  lux_on = Convert_ADC_Lux(VADC);
  //same for off reference
  VADC = Convert_Lux_ADC(lux_off);
  lux_off = Convert_ADC_Lux(VADC);

  //redefine current ref
  if(occupation_state[address_position] == 0)
    lux_ref = lux_off;
  else if(occupation_state[address_position] == 1)
    lux_ref = lux_on;
}

//toogle occupation state
void Luminaire::Set_Occupation_State()
{
  //if on 
  if(occupation_state[address_position]==1)
  { 
    //turn off
    occupation_state[address_position]=0;
    lux_ref = lux_off;
    //inform the network          
    Send_Event(OCC_STATE_OFF, address_position);
  }

  //if off
  else if(occupation_state[address_position]==0)  
  {  
    //turn on
    occupation_state[address_position]=1;          
    lux_ref = lux_on;             
    Send_Event(OCC_STATE_ON, address_position);           
  }

  //flag enabled so feed_forward sees and acts
  flag_state=1; 
}

/**************************************************** CALIBRATION PROCESSES ****************************************************/

//acquir samples from analog pin
float Luminaire::Aquire_Samples(int number)
{
  float value=0;
  int aux;

  //to guarantee good meausure
  if(number<10) number = 10;
  
  for(int i=0; i<number; ++i)
      {
        aux = analogRead(ANALOG_PIN); 
        //only 10 last count because ldr needs to reach equilibrium   
        if( i > 9 )                     
          value += aux;
      }

  //make mean    
  value = value/(number-10.);
  
  return value;
}

//calibrates lux in function of pwm duty-cycle knowing all matrix
void Luminaire::Calibration(void)
{
  
  flag_calib = 1; 

  if(sizeof(gain[0])!= n_nodes)
  {
    realloc(d_pwm_av, n_nodes*sizeof(int));
    realloc(d_arm_pwm, n_nodes*sizeof(int));
    realloc(gain, n_nodes*sizeof(float*));
    realloc(inv_gain, n_nodes*sizeof(float*));
    realloc(il_0, n_nodes*sizeof(float*));
    realloc(occupation_state,n_nodes*sizeof(int));
    for(int i = 0; i<n_nodes; ++i)
    {
      gain[i] = (float*) malloc(n_nodes*sizeof(float));
      inv_gain[i] = (float*) malloc(n_nodes*sizeof(float));
      il_0[i] = (float*) malloc(n_nodes*sizeof(float));
      for(int j = 0; j<n_nodes; ++j)
      {
        gain[i][j] = 0;
        inv_gain[i][j] = 0;
        il_0[i][j] = 0;
      }
    }
  }

      
  int pwm_max = 110;                                             
  for(n_master = 0; n_master<n_nodes; ++n_master)
  { 
    analogWrite(DIGITAL_PIN,0);
    delay(300);
  
    if(n_master==address_position)
    { Serial.println("Master");     
      Send_Event(PWM,(byte) 0);
      flag_pwm = 0;
    
      il_0[n_master][n_master] = Aquire_Samples(20);
      
      for(int i = 0; i<n_nodes; ++i)
      {
        if(i!=address_position)
        {
          Send_Event(ADC_Q,(byte) 1, address_list[i]);
          WaitEvent(ADC_A, 1);
          flag_adc_a = 0;
        }
        else
        {
          Send_Event(ADC_A,il_0[n_master][n_master]);
          n_answers++;
        }
       }

      n_answers = 0;
      analogWrite(DIGITAL_PIN,pwm_max);
      delay(80);
      
      Send_Event(PWM,(byte) 1);
      flag_pwm = 1;
      gain[n_master][n_master] = Aquire_Samples(20);

      for(byte i = 0; i<n_nodes; ++i)
      {
        if(i!=address_position)
        {
          Send_Event(ADC_Q,(byte) 1, address_list[i]);
          WaitEvent(ADC_A, 1);
          flag_adc_a = 0;
        }
        else
        {
          Send_Event(ADC_A,gain[n_master][n_master]);
          n_answers++;
        }
      }
      
      analogWrite(DIGITAL_PIN,0);
      n_answers = 0;
    }
      
    else
    { Serial.println("Slave"); 
      flag_pwm = 1; 
      WaitEvent(PWM, 0); Serial.println("pwm");      
      il_0[address_position][n_master] =  Aquire_Samples(20);
      
      while(n_answers<n_nodes)
      {
        if(flag_receive != 0)
        {
          EventDispatch(); Serial.println("rec");Serial.println(msg_int[1]);Serial.println(flag_adc_a);
          if(flag_adc_q == 1)
          {
            flag_adc_q = 0;
            Send_Event(ADC_A,il_0[address_position][n_master]);
            ++n_answers;
          }
          if(flag_adc_a == 1)
          {
            flag_adc_a = 0;
          }
        } 
      }

      n_answers = 0;
      WaitEvent(PWM, 1);
      gain[address_position][n_master] =  Aquire_Samples(20);
         
      while(n_answers<n_nodes)
      {
        if(flag_receive != 0)
        {
          EventDispatch();
          if(flag_adc_q == 1)
          {
            flag_adc_q = 0;
            Send_Event(ADC_A,gain[address_position][n_master]);
            ++n_answers;
          }
          if(flag_adc_a == 1)
          {
            flag_adc_a = 0;
          }
        }
      } 
      n_answers = 0; 
    }
  }
 
  Matrix.Print((float**)il_0, (int) n_nodes, (int) n_nodes, "il_0 ADC");
  Matrix.Print((float**)gain, (int) n_nodes, (int) n_nodes, "Gain ADC");
  
  for(int i = 0; i<n_nodes; ++i)
  {
    for(int j= 0; j<n_nodes;++j)
    {
      gain[i][j] = Convert_ADC_Lux(gain[i][j]);
      il_0[i][j] = Convert_ADC_Lux(il_0[i][j]);
      gain[i][j] = (gain[i][j]-il_0[0][j])/((float)pwm_max);
    }
  }

  Matrix.Copy((float**)inv_gain, n_nodes, n_nodes, (float**)gain);
  Matrix.Invert((float**)inv_gain, n_nodes);
  Matrix.Print((float**)il_0, n_nodes, n_nodes, "il_0 LUX");
  Matrix.Print((float**)gain, n_nodes, n_nodes, "Gain LUX");
  Matrix.Print((float**)inv_gain, n_nodes, n_nodes, "Inv Gain LUX");

  flag_calib = 10;
}

void Luminaire::Calibration2(void)
{
  unsigned long t_start = millis();        //initiate time counting 

  flag_calib = 2;

  if(sizeof(dc_pwm) != n_nodes)
  {
    realloc(occupation_state,n_nodes*sizeof(int));
    realloc(dc_pwm, n_nodes*sizeof(int));
        
    for(int i = 0; i<2; ++i)
    {
      gain[i] = (float*) malloc(n_nodes*sizeof(float));
      il_0[i] = (float*) malloc(n_nodes*sizeof(float));
      for(int j = 0; j<n_nodes; ++j)
      {
        gain[i][j] = 0;
        il_0[i][j] = 0;
        dc_pwm[j] = 0;
      }
    }
  }
  
  int pwm_max = 70;                                             
  for(n_master = 0; n_master<n_nodes; ++n_master)
  { 

    analogWrite(DIGITAL_PIN,0);
    delay(300);
    
    if(n_master==address_position)
    {
      Send_Event(PWM,(byte) 0);
      flag_pwm = 0;
    
      il_0[0][n_master] = Aquire_Samples(20);
      
      for(int i = 0; i<n_nodes; ++i)
      {
        if(i!=address_position)
        {
          Send_Event(ADC_Q,(byte) 1, address_list[i]);
          WaitEvent(ADC_A, 1);
          flag_adc_a = 0;
        }
        else
        {
          il_0[1][n_answers] = il_0[0][n_answers]; 
          n_answers++;
        }
       }

      n_answers = 0;
      analogWrite(DIGITAL_PIN,pwm_max);
      delay(80);
      
      Send_Event(PWM,(byte) 1);
      flag_pwm = 1;
      gain[0][n_master] = Aquire_Samples(20);

      for(byte i = 0; i<n_nodes; ++i)
      {
        if(i!=address_position)
        {
          Send_Event(ADC_Q,(byte) 1, address_list[i]);
          WaitEvent(ADC_A, 1);
          flag_adc_a = 0;
        }
        else
        {
          gain[1][n_answers] = gain[0][n_answers];
          n_answers++;
        }
      }
      
     analogWrite(DIGITAL_PIN,0);
     n_answers = 0;
    }
      
    else
    {
      flag_pwm = 1; 
      WaitEvent(PWM, 0);      
      il_0[0][n_master] =  Aquire_Samples(20);
      
      while(n_answers<n_nodes-1)
      {
        if(flag_receive != 0)
        {
          EventDispatch();
          if(flag_adc_q == 1)
          {
            flag_adc_q = 0;
            Send_Event(ADC_A,il_0[0][n_master],address_list[n_master]);
            ++n_answers;
          }
        } 
      }

      n_answers = 0;
      WaitEvent(PWM, 1);
      gain[0][n_master] =  Aquire_Samples(20);
         
      while(n_answers<n_nodes-1)
      {
        if(flag_receive != 0)
        {
          EventDispatch();
          if(flag_adc_q == 1)
          {
            flag_adc_q = 0;
            Send_Event(ADC_A,gain[0][n_master],address_list[n_master]);
            ++n_answers;
          }
        }
      } 
      n_answers = 0; 
    }
  }
 
  Matrix.Print((float**)il_0, (int) n_nodes, (int) n_nodes, "il_0 ADC");
  Matrix.Print((float**)gain, (int) n_nodes, (int) n_nodes, "Gain ADC");
  
  for(int i = 0; i<2; ++i)
  {
    for(int j= 0; j<n_nodes;++j)
    {
      gain[i][j] = Convert_ADC_Lux(gain[i][j]);
      il_0[i][j] = Convert_ADC_Lux(il_0[i][j]);
      gain[i][j] = (gain[i][j]-il_0[i][j])/((float)pwm_max);
    }
  }

  Matrix.Print((float**)il_0, 2, n_nodes, "il_0 LUX");
  Matrix.Print((float**)gain, 2, n_nodes, "Gain LUX");
  
  flag_calib = 10;
   
}

/* ROUTINE CONVERT FROM V TO LUX */
float Luminaire::Convert_ADC_Lux(float adc_val)
{
  float lux = pow((((1024./adc_val)-1)/7.), 1/(-0.892));
  return lux;
}

/*ROUTINE CONVERT FROM LUX TO ADC CHANNELS*/
int Luminaire::Convert_Lux_ADC(float lux_val)
{
  int adc_val = 1024./(pow(lux_val,-0.892)*7+1);
  return adc_val;
}

/* ROUTINE CONVERT FROM LUX TO PWM */
int Luminaire::Convert_Lux_PWM()
{
   float pwm = 0;

   //if calibration mode uses all matrix
   if(calib_mode == 1)
   {
    //loop on all nodes
    for(int i=0; i<n_nodes; ++i)
    {
     //if node on
     if(occupation_state[i] == 1)
      pwm += inv_gain[address_position][i]*(lux_on-il_0[0][i]);
     //if node off
     else if(occupation_state[i] == 0)
      pwm += inv_gain[address_position][i]*(lux_off-il_0[0][i]);
    }

    //make sure the pwm value is in the boundaries
    if(pwm < 0)
      pwm = 0;
    else if(pwm>255)
      pwm = 255;
   }

   //if calibration mode only uses own gains
   else if(calib_mode == 2)
   {
     //does 3 iterations to converge on duty-cycle
     for(int i = 0; i<3; ++i)
     {
       //iterates on all nodes
       for(n_master = 0; n_master<n_nodes; ++n_master)
       {
         //auxiliary used to store the new pwm values
         float aux=0;
         //if the node is the current master
         if(n_master == address_position)
         {
            //subtract the external illumination
            aux = lux_ref-il_0[0][address_position];
            //iterate on the contribution off all the other nodes
            for(int j = 0; j<n_nodes; ++j)
            {
              if(j!= address_position)
              {
                //subtract the contribution of other nodes current iillumination
                aux -= gain[0][j]*dc_pwm[j];
              }
            }

            //divide by own gain to return the duty-cycle value
            aux = aux/gain[0][address_position];

            //verify the boundaries
            if(aux < 0)
              aux = 0;
            else if(aux>255)
              aux = 255;

            //actualize duty-cycle values  
            dc_pwm[address_position] = aux;
            //send calculated value to other nodes
            Send_Event(DC_PWM_A,dc_pwm[address_position]);
         }

         //if the node is not the master 
         else
         {
            //wait for the master to do his calculations
            WaitEvent(DC_PWM_A, 1);
            //master did calculation now reset the message flag
            flag_dc_pwm_a = 0;
         }
       }
     }

     //assign final value to output variable
     pwm = dc_pwm[address_position];
   }
 
   return (int)pwm;
}


void Luminaire::WaitEvent(int flag, int value)
{
  int *flag_aux = NULL;
  switch (flag)
  {
    case PWM:
      flag_aux = &flag_pwm;
      break;
    case ADC_Q:
      flag_aux= &flag_adc_q;
      break;
    case ADC_A:
      flag_aux = &flag_adc_a;
      break;
    case DC_PWM_A:
      flag_aux = &flag_dc_pwm_a;
      break;
    case CONSENSUS_PWM:
      flag_aux = &flag_consensus_pwm;
      break;
    case CONSENSUS_AV:
      flag_aux = &flag_consensus_av;
      break;
    default:
      break;
  }
   while(1)
   { 
      if(flag_receive != 0)
      { 
        EventDispatch();
        if(*flag_aux == value){
          return;}
      }    
    }  
}

void Luminaire::EventDispatch()
{
  if(msg_position - 2*flag_receive < 0)
  { 
    Convert_2bytes2msg(msg_int, &msg_byte[sizeof(msg_byte)-2*(flag_receive)+msg_position]);
  }
  else
    Convert_2bytes2msg(msg_int, &msg_byte[msg_position-2*flag_receive]);
  
  if(msg_int[1] == PWM)
  {
    if(msg_int[0]==0)
    {
      analogWrite(11,0);
      delay(10);
      flag_pwm = 0;
    }
    else if(msg_int[0]==1)
      flag_pwm = 1;
    else
      Serial.println("Erro"); 
    flag_receive--;
  } 

  else if(msg_int[1] == ADC_Q)
  {
    if(msg_int[0]==1)
      flag_adc_q = 1;
    else
      Serial.println("Erro");
    flag_receive-- ;
  }

  else if(msg_int[1] == ADC_A)
  {
    flag_adc_a = 1;
    if(calib_mode == 1)
    {
      if(flag_pwm == 0)
        il_0[n_answers][n_master] = msg_int[0];
      if(flag_pwm == 1)
        gain[n_answers][n_master] = msg_int[0];
    }
    else if(calib_mode == 2)
    {
      if(flag_pwm == 0)
        il_0[1][n_answers] = msg_int[0];
      if(flag_pwm == 1)
        gain[1][n_answers] = msg_int[0];
    }
    ++n_answers;
    flag_receive--;
  }

  else if(msg_int[1] == N_NODES)
  {
    if(msg_int[0] == n_nodes)
    {    
      flag_receive--;
      Send_Event(CALIB,(int)1);
      if(calib_mode == 1)
        Calibration();
      if(calib_mode == 2)
        Calibration2();  
    }  
    else if(msg_int[0] > n_nodes)
    {
      Find_Number_Nodes();
      flag_receive--;
    }
    else
      flag_receive--;
  }

  else if(msg_int[1] == CALIB)
  {
    flag_receive--;
    if(calib_mode == 1)
      Calibration();
    if(calib_mode == 2)
      Calibration2();
  }
  
  else if(msg_int[1] == OCC_STATE_ON)
  {
    occupation_state[msg_int[0]]=1;
    flag_receive--;
    flag_state=1;
  }
  else if(msg_int[1] == OCC_STATE_OFF)
  {
    occupation_state[msg_int[0]]=0;
    flag_receive--;
    flag_state=1;
  }
  
  else if(msg_int[1] == DC_PWM_A)
  {
    dc_pwm[n_master] = msg_int[0];
    flag_receive--;
    flag_dc_pwm_a = 1;
  }
  else if(msg_int[1] == CONSENSUS_PWM)
  {
    if(msg_int[0]>255)
    {
      msg_int[0]=-msg_int[0]+512; 
    }
    d_arm_pwm[n_master]=msg_int[0];
    flag_consensus_pwm = 1;
    flag_receive--;    
  }
  else if(msg_int[1] == CONSENSUS_AV)
  {
    d_pwm_av[n_master]=msg_int[0];
    flag_consensus_av = 1;
    flag_receive--;    
  }

  else
    flag_receive --;

}
