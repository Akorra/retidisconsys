/**************************************************************
 *  
 *    Real-Time Distributed Control Systems
 *    Luminaire.h 
 *    
 *    Cristina Melício
 *    Diogo Carvalho
 *    Lino Pereira
 *    
 *    Last Version January 2017
 *
 ***************************************************************/


#ifndef LUM_H
#define LUM_H

#include "ComunicationI2C.h" //comunication protocols
#include <MatrixMath.h>  //used to work with matrix

#define ANALOG_PIN A0    //analog input to read illumination
#define DIGITAL_PIN 11   //pwm pin utilized (f = 500 Hz)


/*** FLAGS UTILIZED IN I2C COMUNICATION ***/
#define PWM 4             //00000100  
#define ADC_Q 8           //00001000  
#define ADC_A 16          //00010000  
#define N_NODES 32        //00100000  
#define CALIB 64          //01000000  
#define OCC_STATE_ON 128  //10000000
#define OCC_STATE_OFF 192 //11000000
#define DC_PWM_A 224      //11100000
#define CONSENSUS_PWM 248 //11111000
#define CONSENSUS_AV 232  //11101000
//NEVER USE, BECAUSE IT'S NEEDED TO FIND NODES 11111100!!!!!!!!!!!!!!


#define ADDRESS 10      //define position on the array
#define OCCUPATION 0    //initial occupation state 0 = off , 1 = on

#define LUX_REF_ON 20   //reference illumination for on/off states (lux)
#define LUX_REF_OFF 10

class Luminaire: public ComunicationI2C{

  public:
  
    Luminaire();                                            //default constructor and destructor
    ~Luminaire();

    //NETWORK INFORMATIONS    
    void Find_Number_Nodes();                                //get number of nodes in the network (first routine to be called)
    void Print_Addresses();                                  //print found addresses

    //set function
    void Set_Lux_ref();                                      //chooses lux_ref values possible to read by the ADC
    void Set_Calibration_Mode(int mode) {if(mode == 1 || mode == 2) calib_mode = mode;} //sets calibration mode 1-Calibration(); 2-Calibration2();
    void Set_Consensus(bool mode){flag_consensus = mode;}    //selects if consensus algorithm is on/off
    void Set_Occupation_State();                             //toggles occupation state

    //calibration processes
    float Aquire_Samples(int N);                             //aquire N samples of analog read
    void Calibration(void);                                  //calibrates lux in function of pwm duty-cycle knowing all matrix
    void Calibration2(void);                                 //calibrates lux in function of pwm duty-cycle knowing only own gains

    //conversion functions
    float Convert_ADC_Lux(float adc_val);                    //convert ADC value to lux
    int Convert_Lux_ADC(float lux_val);                      //convert lux value to ADC
    int Convert_Lux_PWM();                                   //convert lux value to PWM (needs calibration first)  

    //message interpretation functions
    void WaitEvent(int flag, int value);                     //waits on loop for a specific event to occur  
    void EventDispatch();                                    //decodes incoming messages

    //return functions
    int Get_Number_Nodes(){return n_nodes;}                  //number of nodes on the network
    int Get_Ocupation_State(){return occupation_state[address_position];} //occupation state
    float Get_Lux_Ref(){return lux_ref;}                     //current illumination references 
    float Get_Lux_Off(){return lux_off;}                     //off reference
    float Get_Lux_On(){return lux_on;}                       //on reference

    //PUBLIC VARIABLES
    byte msg_byte[50];                                      //circular buffer used for communication
    int msg_position = 0;                                   //current position of last message on buffer
    volatile int flag_receive = 0;                          //current number of messages waiting for decoding
    int  msg_int[2];                                        //decoded message 
    int flag_state;                                         //1 - change in occupation state, 0 - no change in occupation
    int flag_calib;                                         //0 - calibration not done, 10 - calibration done waiting feedforward, 
                                                            //1 - calibration and feedforward done
    
  protected:

    //NETWORK INFORMATIONS
    byte address;            //addrees of the luminaire
    int n_nodes = 0;         //total number of luminaires
    byte address_list[128];  //list of existing addresses (size makes sure we have enough space)
    int address_position = 0;//position in addresss_list array
    int* occupation_state;   //list of all occupation states of all luminaires
    
    //WORKING MODE
    int calib_mode;            //choosen calibration mode
    bool flag_consensus=false; //consensus used or not

    //REFERENCE VALUES
    float lux_ref;           //current lux reference
    float lux_on;            //lux value if there are people on the room
    float lux_off;           //lux value if there are not people on the room 

    //CALIBRATION VARIABLES
    float** il_0;            //lux values of every LDR with led off
    float** gain;            //gains for feedforwar matrix
    float** inv_gain;        //inverted gain matrix
    int* dc_pwm;             //values of duty-cycles on all luminaries (used at feedforward for iterative process)
    int n_master = 0;        //current master  in calibration process
    int n_answers = 0;       //current number of aswers to a certain question


    //flags used for decoding of message
    int flag_pwm = 0;            //PWM event
    int flag_adc_q = 0;          //ADC_Q event
    int flag_adc_a = 0;          //ADC_A event
    int flag_dc_pwm_a = 0;       //DC_PWM_A event 
    int flag_consensus_pwm = 0;  //CONSENSUS_PWM event 
    int flag_consensus_av = 0;   //CONSENSUS_AV event
    

    //CONSENSUS VARIABLES
    int *d_arm_pwm;
    int *d_pwm_av;



};

extern Luminaire luminaire;


#endif
