/**************************************************************
 *  
 *    Real-Time Distributed Control Systems
 *    LightController.h 
 *    
 *    Cristina Melício
 *    Diogo Carvalho
 *    Lino Pereira
 *    
 *    Last Version January 2017
 *
 ***************************************************************/

#ifndef PID_H
#define PID_H

#include "Luminaire.h"

#define KP 2.6          // constante de proporcionalidade
#define KI 0.02         // constante de integração

#define RHO 0.1
#define N_ITER 20
#define TS 625          

#define COST 1           //energy cost per W
#define E_COST 0.1        //lamp cost

class LightController: public Luminaire {
  
  public:
    LightController();         
    ~LightController();             
 
    void LightControllerSetup();                            
    void FeedForward();                                     
    void PIController();
    float Calculate_External_Light();

    int Get_DC_pwm(){return dc_pwm[address_position];}
    float Get_Lux_Value(){return y;}
    void Memory_Realloc();

//--------------------------CONSENSUS---------------------------------//
    float CostFunction();
    void Unconstrained_Sol();
    void Linear_Sol();
    void LowerBoundary_Sol();
    void UpperBoundary_Sol();
    void Linear_Lower_Sol();
    void Linear_Upper_Sol();
    int Unconstrained_Region();
    int Linear_Region();
    int LowerBoundary_Region();
    int UpperBoundary_Region();
    int Linear_Lower_Region();
    int Linear_Upper_Region();

    void Consensus_Minimun();
    void AuxilarCalc();

    void ConsensusAlgorithm();

 private:
 //--------------------------CONSENSUS---------------------------------//
    //int *d_pwm_av;       //vetor com os dc_pwm de cada node calculado no address_position
    float *d_pwm_aux;
    int *d_pwm_best;
    float *lambdas;      //vector com os multiplicadores de lagrange no address_position
    float *z;            //vector auxiliar ao algoritmo 
    float *v;            //vector auxiliar ao algoritmo 
    float g;             
    float cost;          //custo dinheiro
    float e_cost;        //custo energético
    float norm_gain;     //norma do ganho 
    float norm_gain_2;   //norma 2 do ganho
    float min_best;
     
    int pwm;       //duty cicle of pwm
    float y;       //values readed in the arduino
    float y_ant;   //last lux value measured
    float i_ant;   //last integral meausered
    float e_ant;   //last error meausered
    float e;       //error meausered
    float e_sat;   //difference between pwm asked and max/min value possible
    float p;       //proportional term
    float i;       //integral term
    float K1;      //kp
    float K2;      //kp*ki
};

extern LightController light1;


#endif
