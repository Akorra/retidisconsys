#include <Arduino.h>
#include "Luminaire_One.h"

/* DEFAULT CONSTRUCTOR */
Luminaire_One::Luminaire_One()
{
  //starts off by default
  state = 0;
  //start PI by defalut              
  state_PI = 1;           
  lux_ref = LUX_REF_OFF;   
  lux_on = LUX_REF_ON;
  lux_off = LUX_REF_OFF;
  dc_pwm = 0;
  gain = 0;
  il_0 = 0;
  y_ant = 0;
  i_ant = 0;
  e_ant = 0;
  y = 0;
  e = 0;
  p = 0;
  i = 0;
  e_sat = 0;
  K1 = KP;
  K2 = KP*KI/2;
   
}
/* ROUTINE CONVERT FROM V TO LUX */
double Luminaire_One::Convert_ADC_Lux(double adc_val)
{
  double lux = pow((((1024./adc_val)-1)/7.), 1/(-0.892));
  return lux;
}

/*ROUTINE CONVERT FROM LUX TO V*/
int Luminaire_One::Convert_Lux_ADC(double lux_val)
{
  int ADC_val = 1024./(pow(lux_val,-0.892)*7+1);
  return ADC_val;
}

/*ROUTINE CONVERT FROM LUX TO PWM*/
int Luminaire_One::Convert_Lux_PWM(double lux_val)
{
  int PWM = (lux_val-il_0)/gain;
  return PWM;
}

/* CALIBRATION ROUTINE FOR GAIN AND IL_0 */
void Luminaire_One::Calibration(void)
{
  //unsigned long t_start = millis();                             //initiate time counting 
  int data[20];                                                   //auxiliary to store values
  float il_255 = 0;                                               //ilumination on PWM = 255 

  for(int i=0; i<20; ++i){
     data[i] = analogRead(A0);                                     //acquire 20 values from A0
     if( i > 9 ){                                                  //only 10 last count because we need to reach equilibrium
      il_0 += data[i];
     }
  }
  
  il_0 = il_0/10.;                                                 //make the mean 
  il_0 = Convert_ADC_Lux(il_0);                                    //convert to lux 

  analogWrite(11,255);                                            //PWM on pin 11
  delay(100);                                                     //delay must be here if not analogRead doesn't work correctly
  for(int i = 0; i<20; ++i){
   
    data[i] = analogRead(A0);                                      //acquire 20 values from A0
    if( i > 9 ){                                                   //only 10 last count because we need to reach equilibrium
      il_255 += data[i];
    }
  } 

  il_255 = il_255/10.;                                              //make the mean
  il_255 = Convert_ADC_Lux(il_255);                                 //convert to lux 
  gain = (il_255-il_0)/255.;                                         //calculate the gain 
  
  dc_pwm_off = Convert_Lux_PWM(lux_off);
  dc_pwm_on = Convert_Lux_PWM(lux_on);

  FeedForward();

  //unsigned long t_end = millis();                                  //finishing time of calibration 
  //unsigned long dt_calib = t_end - t_start;                        //dt needed to calibrate
}

/* CALIBRATION ROUTINE FOR EVERY PWM VALUE */
void Luminaire_One::Calibration2(void)
{  
  unsigned long t_start = millis();                               //initiate time counting                                     
  int i,j;                                                        //auxiliary iterators

  //loop on every possible value of pwm dutycicle
  for(i=0;i<sizeof(Lux_PWM)/sizeof(float);++i)
  {
      analogWrite(11,i);                                          //choose pwm dutycicle
      delay(15);                                                  //delay needed for led to stabilize
      Lux_PWM[i] = 0;                                             //reset value

      //loop to make mean and remove noise
      for(int j = 0; j<30;++j)
      {
         Lux_PWM[i] += analogRead(A0);
         //Serial.println(analogRead(A0));
         delayMicroseconds(1);
      } 
      
      Lux_PWM[i] = Convert_ADC_Lux(Lux_PWM[i]/30.);
      
      if( i != 0 && Lux_PWM[i] > lux_on && Lux_PWM[i-1] < lux_on )
      {
        dc_pwm_on = i-1;
        e_lux_on_u = Lux_PWM[i] - lux_on;                      //errors useful for deadzone calculation
        e_lux_on_d = Lux_PWM[i-1] - lux_on;
      }

      //discover interval where our lux_on value is
      if( i != 0 && Lux_PWM[i] > lux_off && Lux_PWM[i-1] < lux_off )
      {
        dc_pwm_off = i-1;
        e_lux_off_u = Lux_PWM[i] - lux_off;                    //errors useful for deadzone calculation
        e_lux_off_d = Lux_PWM[i-1] - lux_off;
      }
  }

  if(dc_pwm_on == 0)
  dc_pwm_on = 255;

  analogWrite(11,0);                                               //turn off led otherwise for safety
  delay(10);
  unsigned long t_end = millis();                                  //finishing time of calibration 
  unsigned long dt_calib = t_end - t_start;                        //dt needed to calibrate
}

void Luminaire_One::PISetup(void)
{
  //make lux_on and lux_off a value possible for the ADC
  int VADC = Convert_Lux_ADC(lux_on);
  
  lux_on = Convert_ADC_Lux(VADC);
  e_lux_on_u2 = Convert_ADC_Lux(VADC+1) - lux_on;
  e_lux_on_d2 = Convert_ADC_Lux(VADC-1) - lux_on;
  
  VADC = Convert_Lux_ADC(lux_off);
  lux_off = Convert_ADC_Lux(VADC);
  
  e_lux_off_u2 = Convert_ADC_Lux(VADC+1) - lux_off;
  e_lux_off_d2 = Convert_ADC_Lux(VADC-1) - lux_off;
  
  if(state == 0)
  lux_ref = lux_off;
  else if(state == 1)
  lux_ref = lux_on;
}


void Luminaire_One::PIController(void)
{
    e = lux_ref - y;
    
    if( e >  e_lux_off_d && e <  e_lux_off_u  && state == 0 )
      e=0; 
    else if(  e >  e_lux_on_d && e <  e_lux_on_u  && state == 1 )
      e=0;
      
    p = K1*e;
    i = i_ant + K2*(e+e_ant);
    dc_pwm = dc_pwm + p + i;
        
    if(dc_pwm >= 255)
      {
        e_sat = 255 - dc_pwm;
        dc_pwm = 255;
      }
    else if (dc_pwm < 0)
      {
        e_sat = - dc_pwm;
        dc_pwm = 0;
      }
    else
      e_sat = 0;

    analogWrite(11,dc_pwm);
 
    i_ant = i+e_sat/50.;
    y_ant = y;
    e_ant = e; 
    
    Serial.println(y);
}

void Luminaire_One::FeedForward()
{
  if(state == 1)
  dc_pwm = dc_pwm_on;
  else if(state == 0)
  dc_pwm = dc_pwm_off;
  analogWrite(11,dc_pwm);
  Serial.println(y);
}

void Luminaire_One::ChangeState(int new_state)
{
  // not occupied
  if(new_state==0 || new_state == '0')
  { 
    lux_ref = lux_off;            // change lux_ref to off
    state = 0;   
    FeedForward();  
  }
  // occupied
  else if(new_state==1 || new_state == '1')  
  {            
    lux_ref = lux_on;             // change lux_ref to on
    state = 1;
    FeedForward();  
  }
  // PI mode
  else if(new_state == 3)
    state_PI = 1;
  // Feedforward mode
  else if(new_state == 2)
    state_PI = 0;
  
}

void Luminaire_One::AcquireAverage() 
{     
      int i;
      //various aquisitions to remove noise
      for(i=0;i<100;++i)
      {
        delayMicroseconds(1);
        light1.y+=analogRead(A0);
      }
      //make mean and convert to lux
      light1.y = light1.Convert_ADC_Lux(light1.y/100.);  
}

Luminaire_One light1 = Luminaire_One();
