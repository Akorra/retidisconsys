#ifndef PID_H
#define PID_H

#define LUX_REF_ON 20
#define LUX_REF_OFF 10
#define KP 2.6          // constante de proporcionalidade
#define KI 0.02         // constante de integração
#define TIME 90         // sampling time

/*************************ADICIONAR para funcionar com ISR *******************************/
#include <avr/io.h>
#include <avr/interrupt.h>
#define TS 600 //3124 - corresponde a 200 ms
/********************************************************/
class Luminaire_One {
  
  public:
    Luminaire_One();                          //constructor
    void AcquireAverage();
    double Convert_ADC_Lux(double adc_val);   //convert ADC value to lux
    int Convert_Lux_ADC(double lux_val);      //convert lux value to ADC
    int Convert_Lux_PWM(double lux_val);      //convert lux value to PWM (needs calibration first)
    void Calibration(void);                   //calibrates lux in function of pwm duty-cicle
    void Calibration2(void);                  
    void FeedForward();                       //feedforward mode
    void PISetup(void);                       //resets terms used on PI
    void PIController(void);                  //PI loop
    void ChangeState(int);                    
    int StatePI(void){return state_PI;}      //returns selected controller mode 0-feedforward 1-PI
    double y;                                 //value meausered

  private:
  
    double lux_ref; //lux value we want to achieve
    double lux_on;  //lux value if there are people on the room
    double lux_off; //lux value if there are not people on the room

    int dc_pwm;     //duty cicle of pwm
    double gain;    //pwm to lux gain
    double il_0;    //lux value with led off
    
    double y_ant;   //last lux value measured
    double i_ant;   //last integral meausered
    double e_ant;   //last error meausered
    double e;       //error meausered
    double e_sat;   //difference between pwm asked and max/min value possible
    double p;       //proportional term
    double i;       //integral term
    double K1;      //kp
    double K2;      //kp*ki
    
    int state;       //1 if table occupied 0 if not
    int state_PI;    //1 if PI is used 0 if feedforward

    float Lux_PWM[256];  //values recheable py PWM DC
    int dc_pwm_on;
    int dc_pwm_off;
    float e_lux_on_u;   //errors for the dead zone still working on it
    float e_lux_on_d; 
    float e_lux_off_u;
    float e_lux_off_d; 
    float e_lux_on_u2;   //errors for the dead zone still working on it
    float e_lux_on_d2; 
    float e_lux_off_u2;
    float e_lux_off_d2; 

};

extern Luminaire_One light1;


#endif
