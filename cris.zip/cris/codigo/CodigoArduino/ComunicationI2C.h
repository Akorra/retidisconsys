/**************************************************************
 *  
 *    Real-Time Distributed Control Systems
 *    ComunicationI2C.h 
 *    
 *    Cristina Melício
 *    Diogo Carvalho
 *    Lino Pereira
 *    
 *    Last Version January 2017
 *
 ***************************************************************/

#ifndef I2C_H
#define I2C_H

#include <Wire.h>
#include <Arduino.h>
#include <stdlib.h>

class LightController;

class ComunicationI2C {

  public:
    ComunicationI2C(){;}                       
    void Send_Event(int ask, int msg);                          //send message in broad-cast
    void Send_Event(int ask, int msg, byte address_device);     //send message to specified address
    void Convert_2msg2bytes(int ask, int msg, byte* msg_byte);  //convert message in 2 bytes
    void Convert_2bytes2msg(int* msg_int, byte* msg_bytes);     //convert 2 bytes back to message
    void Convert_2msg2bytes_Neg(int ask, int msg, byte* msg_byte);  //convert message in 2 bytes for negative value
 };

extern ComunicationI2C i2c;

#endif
