#include "ComunicationI2C.h"

//CONVERTE 2 MSG EM 2 BYTES
void ComunicationI2C::Convert_2msg2bytes(int ask, int msg, byte* msg_byte)
{
  //8 least significant bits
  msg_byte[0] = msg;
  //question + 2 most significant bits
  msg_byte[1] = msg>>8;
  msg_byte[1] += (byte)ask;
}

//CONVERTE 2 MSG EM 2 BYTES CASO 
void ComunicationI2C::Convert_2msg2bytes_Neg(int ask, int msg, byte* msg_byte)
{
  //8 least significant bits
  msg_byte[0] = abs(msg);
  //question + 2 most significant bits
  if(msg < 0)
    msg_byte[1] = 1;
  else
    msg_byte[1] = 0;  
  msg_byte[1] += (byte)ask;
}


//CONVERTE 2 BYTES EM 2 MSG
void ComunicationI2C::Convert_2bytes2msg(int* msg_int, byte* msg_bytes)
{
  //value
  msg_int[0] = (int)msg_bytes[0]+ (((int)msg_bytes[1] & (B00000011))<< 8); 
  //question
  msg_int[1] = (int)msg_bytes[1]&(B11111100);   
}



//ENVIA UM EVENTO EM BROADCAST
void ComunicationI2C::Send_Event(int ask, int msg)
{
  byte msg_byte[2];
  if(msg<0) Convert_2msg2bytes_Neg(ask,msg,msg_byte);
  else Convert_2msg2bytes(ask,msg,msg_byte);
  
  Wire.beginTransmission(0x00); //transmit to every device
  Wire.write(msg_byte[1]);      //question + 2 most significant bits
  Wire.write(msg_byte[0]);      //8 least significant bits
  Wire.endTransmission();       // stop transmitting
}

//ENVIA UM EVENTO EM PARA UM ADDRESS ESPECIFICO
void ComunicationI2C::Send_Event(int ask, int msg, byte address_device)
{
  byte msg_byte[2];

  if(msg<0) Convert_2msg2bytes_Neg(ask,msg,msg_byte);
  else Convert_2msg2bytes(ask,msg,msg_byte);
  
  Wire.beginTransmission(address_device); //transmit to every device
  Wire.write(msg_byte[1]);                //question + 2 most significant bits
  Wire.write(msg_byte[0]);                //8 least significant bits
  Wire.endTransmission();                 //stop transmitting
}



